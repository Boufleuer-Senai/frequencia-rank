// Admin login, file upload, and PDF parsing code
