// Storage helpers and rendering code
